/* 
 * File:   newfile.h
 * Author: dimitri
 *
 * Created on October 7, 2013, 1:52 PM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

