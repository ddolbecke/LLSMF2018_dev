/* 
 * File:   PmodMAXSONAR.h
 * Author: Dimitri
 *
 * Created on 16 octobre 2015, 12:32
 */

#ifndef SONAR_H
#define	SONAR_H

#define SONAR_CONNECTED_TO_JB2

void initSonar();
unsigned short getDistance();



#endif	/* SONAR_H */

