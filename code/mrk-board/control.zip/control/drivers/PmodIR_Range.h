/* 
 * File:   PmodMAXSONAR.h
 * Author: Dimitri
 *
 * Created on 16 octobre 2015, 12:32
 */

#ifndef IR_RANGE_H
#define	IR_RANGE_H

#define IR_RANGE_CONNECTED_TO_JJ2
// possible connections : JJ1, JJ2, JB2
void initIR_range();
unsigned short getIR_range();



#endif	/* SONAR_H */

